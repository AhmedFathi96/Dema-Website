import ContentWrapperOne from "@components/wrapper/ContentWrapperOne";

export {ContentWrapperOne}