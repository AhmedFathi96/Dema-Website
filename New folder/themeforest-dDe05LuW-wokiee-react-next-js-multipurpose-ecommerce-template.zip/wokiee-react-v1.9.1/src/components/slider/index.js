import SliderOne from "@components/slider/SliderOne";
import SliderTwo from "@components/slider/SliderTwo";
import SliderThree from "@components/slider/SliderThree";
import SliderFour from "@components/slider/SliderFour";
import SliderFive from "@components/slider/SliderFive";

export {SliderOne, SliderTwo, SliderThree, SliderFour, SliderFive}