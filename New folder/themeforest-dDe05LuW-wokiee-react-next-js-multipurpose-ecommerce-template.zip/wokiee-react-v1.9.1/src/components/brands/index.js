import BrandsOne from "@components/brands/BrandsOne";
import BrandsTwo from "@components/brands/BrandsTwo";
import BrandsThree from "@components/brands/BrandsThree";

export {BrandsOne, BrandsTwo, BrandsThree}