import ContactMethod from "@components/contact/ContactMethod";
import ContactForm from "@components/contact/ContactForm";

export {ContactMethod, ContactForm}