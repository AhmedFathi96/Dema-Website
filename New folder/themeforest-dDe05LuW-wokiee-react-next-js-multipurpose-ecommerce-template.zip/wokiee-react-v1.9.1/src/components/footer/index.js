import FooterOne from "@components/footer/FooterOne";
import FooterTwo from "@components/footer/FooterTwo";
import FooterThree from "@components/footer/FooterThree";
import FooterFour from "@components/footer/FooterFour";
import FooterFive from "@components/footer/FooterFive";
import FooterSix from "@components/footer/FooterSix";
import FooterSeven from "@components/footer/FooterSeven";
import FooterEight from "@components/footer/FooterEight";

export {FooterOne, FooterTwo, FooterThree, FooterFour, FooterFive, FooterSix, FooterSeven, FooterEight}