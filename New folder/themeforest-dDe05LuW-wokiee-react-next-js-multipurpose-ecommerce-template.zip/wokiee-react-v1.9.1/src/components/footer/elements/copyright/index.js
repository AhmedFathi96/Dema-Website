import CopyrightOne from "@components/footer/elements/copyright/CopyrightOne";
import CopyrightTwo from "@components/footer/elements/copyright/CopyrightTwo";
import CopyrightThree from "@components/footer/elements/copyright/CopyrightThree";

export {CopyrightOne, CopyrightTwo, CopyrightThree}