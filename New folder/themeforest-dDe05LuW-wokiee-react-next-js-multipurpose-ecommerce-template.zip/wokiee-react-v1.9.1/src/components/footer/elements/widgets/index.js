import WidgetsOne from "@components/footer/elements/widgets/WidgetsOne";
import WidgetsTwo from "@components/footer/elements/widgets/WidgetsTwo";

export {WidgetsOne, WidgetsTwo}