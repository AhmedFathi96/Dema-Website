import BlogMasonry from "@components/blog-page/BlogMasonry";

export {BlogMasonry}