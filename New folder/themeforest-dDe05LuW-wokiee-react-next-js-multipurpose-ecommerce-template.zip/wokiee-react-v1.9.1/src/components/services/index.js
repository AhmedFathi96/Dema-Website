import ServicesOne from "@components/services/ServicesOne";
import ServicesTwo from "@components/services/ServicesTwo";
import ServicesThree from "@components/services/ServicesThree";

export {ServicesOne, ServicesTwo, ServicesThree}