import TestimonialOne from "@components/testimonials/TestimonialOne";
import TestimonialTwo from "@components/testimonials/TestimonialTwo";

export {TestimonialOne, TestimonialTwo}