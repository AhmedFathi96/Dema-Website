import DesktopHeaderOne from "@components/header/desktop/DesktopHeaderOne";
import DesktopHeaderTwo from "@components/header/desktop/DesktopHeaderTwo";
import DesktopHeaderThree from "@components/header/desktop/DesktopHeaderThree";
import DesktopHeaderFour from "@components/header/desktop/DesktopHeaderFour";
import DesktopHeaderFive from "@components/header/desktop/DesktopHeaderFive";
import DesktopHeaderSix from "@components/header/desktop/DesktopHeaderSix";
import DesktopHeaderSeven from "@components/header/desktop/DesktopHeaderSeven";

export {
    DesktopHeaderOne,
    DesktopHeaderTwo,
    DesktopHeaderThree,
    DesktopHeaderFour,
    DesktopHeaderFive,
    DesktopHeaderSix,
    DesktopHeaderSeven
}