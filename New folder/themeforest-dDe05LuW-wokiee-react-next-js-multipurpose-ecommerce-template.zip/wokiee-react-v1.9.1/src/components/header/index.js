import HeaderOne from "@components/header/HeaderOne";
import HeaderTwo from "@components/header/HeaderTwo";
import HeaderThree from "@components/header/HeaderThree";
import HeaderFour from "@components/header/HeaderFour";
import HeaderFive from "@components/header/HeaderFive";
import HeaderSix from "@components/header/HeaderSix";
import HeaderSeven from "@components/header/HeaderSeven";
import HeaderEight from "@components/header/HeaderEight";
import HeaderNine from "@components/header/HeaderNine";
import HeaderTen from "@components/header/HeaderTen";
import HeaderEleven from "@components/header/HeaderEleven";
import HeaderTwelve from "@components/header/HeaderTwelve";
import HeaderThirteen from "@components/header/HeaderThirteen";

export {
    HeaderOne,
    HeaderTwo,
    HeaderThree,
    HeaderFour,
    HeaderFive,
    HeaderSix,
    HeaderSeven,
    HeaderEight,
    HeaderNine,
    HeaderTen,
    HeaderEleven,
    HeaderTwelve,
    HeaderThirteen
}