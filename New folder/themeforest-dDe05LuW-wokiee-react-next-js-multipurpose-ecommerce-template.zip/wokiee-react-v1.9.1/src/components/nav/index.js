import DesktopNav from "@components/nav/DesktopNav";
import MobileNav from "@components/nav/MobileNav";

export {DesktopNav, MobileNav}