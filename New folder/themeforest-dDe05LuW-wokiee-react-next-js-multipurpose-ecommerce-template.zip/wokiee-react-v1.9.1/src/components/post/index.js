import PostGrid from "./PostGrid";

export {PostGrid};