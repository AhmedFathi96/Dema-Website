import OfferItemOne from "@components/offer/OfferItemOne";

export {OfferItemOne}