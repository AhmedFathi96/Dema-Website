import BrandOne from "@components/brand/BrandOne";
import BrandTwo from "@components/brand/BrandTwo";

export {BrandOne, BrandTwo}