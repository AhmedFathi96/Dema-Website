import PromoBannerOne from "@components/promo-banners/PromoBannerOne";
import PromoBannerTwo from "@components/promo-banners/PromoBannerTwo";
import PromoBannerThree from "@components/promo-banners/PromoBannerThree";
import PromoBannerFour from "@components/promo-banners/PromoBannerFour";
import PromoBannerFive from "@components/promo-banners/PromoBannerFive";
import PromoBannerBabySkin from "@components/promo-banners/PromoBannerBabySkin";
import PromoBannerCareSkin from "@components/promo-banners/PromoBannerCareSkin";
import PromoBannerSix from "@components/promo-banners/PromoBannerSix";
import PromoBannerCookware from "@components/promo-banners/PromoBannerCookware";
import PromoBannerFlower from "@components/promo-banners/PromoBannerFlower";
import PromoBannerFoods from "@components/promo-banners/PromoBannerFoods";
import PromoBannerFurniture from "@components/promo-banners/PromoBannerFurniture";

export {
    PromoBannerOne,
    PromoBannerTwo,
    PromoBannerThree,
    PromoBannerFour,
    PromoBannerFive,
    PromoBannerBabySkin,
    PromoBannerCareSkin,
    PromoBannerSix,
    PromoBannerCookware,
    PromoBannerFlower,
    PromoBannerFoods,
    PromoBannerFurniture
}