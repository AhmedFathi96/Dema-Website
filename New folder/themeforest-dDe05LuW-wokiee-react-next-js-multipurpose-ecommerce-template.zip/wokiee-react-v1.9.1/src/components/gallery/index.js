import GalleryOne from "@components/gallery/GalleryOne";

export {GalleryOne}