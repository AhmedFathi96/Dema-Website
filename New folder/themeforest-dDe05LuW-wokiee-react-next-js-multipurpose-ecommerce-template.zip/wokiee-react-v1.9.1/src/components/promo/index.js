import PromoOne from "@components/promo/PromoOne";
import PromoTwo from "@components/promo/PromoTwo";
import PromoThree from "@components/promo/PromoThree";

export {PromoOne, PromoTwo, PromoThree}