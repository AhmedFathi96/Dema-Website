import AboutOne from "@components/about/AboutOne";
import AboutTwo from "@components/about/AboutTwo";
import AboutThree from "@components/about/AboutThree";
import AboutFour from "@components/about/AboutFour";
import AboutFive from "@components/about/AboutFive";
import AboutSix from "@components/about/AboutSix";

export {AboutOne, AboutTwo, AboutThree, AboutFour, AboutFive, AboutSix}