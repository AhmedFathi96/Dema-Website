import CategoryOne from "@components/category/CategoryOne";
import CategoryTwo from "@components/category/CategoryTwo";
import CategoryThree from "@components/category/CategoryThree";
import CategoryFour from "@components/category/CategoryFour";

export {CategoryOne, CategoryTwo, CategoryThree, CategoryFour}