import CategoriesOne from "@components/categories/CategoriesOne";
import CategoriesTwo from "@components/categories/CategoriesTwo";
import CategoriesThree from "@components/categories/CategoriesThree";
import CategoriesFour from "@components/categories/CategoriesFour";
import CategoriesFive from "@components/categories/CategoriesFive";
import CategoriesSix from "@components/categories/CategoriesSix";
import CategoriesSeven from "@components/categories/CategoriesSeven";
import CategoriesEight from "@components/categories/CategoriesEight";
import CategoriesNine from "@components/categories/CategoriesNine";
import CategoriesTen from "@components/categories/CategoriesTen";
import CategoriesSkinBaby from "@components/categories/CategoriesSkinBaby";
import CategoriesSkinCookware from "@components/categories/CategoriesSkinCookware";
import CategoriesSkinFlower from "@components/categories/CategoriesSkinFlower";
import CategoriesSkinFurniture from "@components/categories/CategoriesSkinFurniture";

export {
    CategoriesOne,
    CategoriesTwo,
    CategoriesThree,
    CategoriesFour,
    CategoriesFive,
    CategoriesSix,
    CategoriesSeven,
    CategoriesEight,
    CategoriesNine,
    CategoriesTen,
    CategoriesSkinBaby,
    CategoriesSkinCookware,
    CategoriesSkinFlower,
    CategoriesSkinFurniture
}