import HeroBannerOne from "@components/hero-banners/HeroBannerOne";
import HeroBannerTwo from "@components/hero-banners/HeroBannerTwo";
import HeroBannerThree from "@components/hero-banners/HeroBannerThree";
import HeroBannerFour from "@components/hero-banners/HeroBannerFour";
import HeroBannerFive from "@components/hero-banners/HeroBannerFive";
import HeroBannerSix from "@components/hero-banners/HeroBannerSix";
import HeroBannerSeven from "@components/hero-banners/HeroBannerSeven";
import HeroBannerEight from "@components/hero-banners/HeroBannerEight";

export {
    HeroBannerOne,
    HeroBannerTwo,
    HeroBannerThree,
    HeroBannerFour,
    HeroBannerFive,
    HeroBannerSix,
    HeroBannerSeven,
    HeroBannerEight
}