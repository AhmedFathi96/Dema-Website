import HomePagesNavData from "./home-pages.json";
import SkinBabyNavData from "./skin-baby.json";
import SkinCareNavData from "./skin-care.json";
import SkinCakeNavData from "./skin-cake.json";
import SkinCoffeeNavData from "./skin-coffee.json";
import SkinComicBooksNavData from "./skin-comic-books.json";
import SkinCookwareNavData from "./skin-cookware.json"
import SkinFlowerNavData from "./skin-flower.json"
import SkinFoodNavData from "./skin-food.json"
import SkinTShirtNavData from "./skin-t-shirt.json"
import SkinTeaNavData from "./skin-tea.json"

export {
    HomePagesNavData,
    SkinBabyNavData,
    SkinCareNavData,
    SkinCakeNavData,
    SkinCoffeeNavData,
    SkinComicBooksNavData,
    SkinCookwareNavData,
    SkinFlowerNavData,
    SkinFoodNavData,
    SkinTShirtNavData,
    SkinTeaNavData
}