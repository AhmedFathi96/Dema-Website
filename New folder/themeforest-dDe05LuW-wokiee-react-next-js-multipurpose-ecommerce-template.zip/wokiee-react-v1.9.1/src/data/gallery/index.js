import GalleryDataBaby from "./gallery-baby.json";

export {GalleryDataBaby}