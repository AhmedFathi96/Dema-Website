// CURRENCY SYMBOL
export const CURRENCY = '$';

// Template Unique Prefix
export const PREFIX = "ht-wokiee";